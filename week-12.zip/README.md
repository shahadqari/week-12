# week-10

## Steps to begin
1. Fork this repository: _click the fork button on the right just above this repository_
2. Clone the forked repository
> git clone "forked repository link"

3. Navigate into the folder
> cd Week-9

4. Setup a python server
> python -m SimpleHTTPServer

5. Go to your browser and open the url: _http://localhost:8000/_
